export { metadata } from '../metadata';

export default function MenuPerformanceLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
} 