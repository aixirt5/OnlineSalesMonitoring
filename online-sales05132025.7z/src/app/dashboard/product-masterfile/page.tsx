'use client';

import { useState } from 'react';

interface Product {
  id: string;
  code: string;
  name: string;
  category: string;
  unit_price: number;
  cost: number;
  status: 'active' | 'inactive';
}

export default function ProductMasterfile() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [products, setProducts] = useState<Product[]>([]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'PHP',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-200 via-sky-100 to-sky-300 p-2 sm:p-4 md:p-6 max-w-[1600px] mx-auto w-full overflow-x-hidden box-border">
      {/* Header Section */}
      <div className="mb-4 sm:mb-6 md:mb-8">
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-sky-700 tracking-tight drop-shadow-sm">
          Product Masterfile
        </h1>
        <p className="mt-1 sm:mt-2 text-sm sm:text-base text-sky-600 max-w-3xl">
          Manage your product catalog and inventory items
        </p>
      </div>

      {/* Actions Section */}
      <div className="mb-4 sm:mb-6 md:mb-8 bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg border border-sky-100 p-3 sm:p-4 md:p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Search Bar */}
          <div className="w-full col-span-1 sm:col-span-2">
            <label className="block text-sm font-medium text-sky-700 mb-1.5">Search Products</label>
            <div className="relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by product name, code, or category..."
                className="w-full border border-sky-300 bg-white/70 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-sky-400 focus:border-sky-400 shadow-sm"
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <svg className="h-5 w-5 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
          </div>

          {/* Add Product Button */}
          <div className="w-full flex items-end">
            <button
              onClick={() => {
                // TODO: Implement add product functionality
                console.log('Add new product');
              }}
              className="w-full bg-sky-600 hover:bg-sky-700 text-white font-semibold py-2.5 px-4 rounded-lg transition-colors duration-200 shadow-sm flex items-center justify-center space-x-2"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              <span>Add New Product</span>
            </button>
          </div>
        </div>
      </div>

      {/* Content Section */}
      {loading ? (
        <div className="flex items-center justify-center h-64 bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg border border-sky-100">
          <div className="text-center p-6">
            <div className="text-sky-600 text-lg font-semibold mb-2">Loading...</div>
            <p className="text-sky-500 text-sm">Please wait while we load the product list.</p>
          </div>
        </div>
      ) : error ? (
        <div className="flex items-center justify-center h-64 bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg border border-red-100">
          <div className="text-center p-6">
            <div className="text-red-600 text-lg font-semibold mb-2">{error}</div>
            <p className="text-red-500 text-sm">Please try refreshing the page or contact support if the issue persists.</p>
          </div>
        </div>
      ) : (
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg border border-sky-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-sky-100">
              <thead className="bg-sky-50/80">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-bold text-sky-500 uppercase tracking-wider">Code</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-sky-500 uppercase tracking-wider">Name</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-sky-500 uppercase tracking-wider">Category</th>
                  <th className="px-6 py-4 text-right text-xs font-bold text-sky-500 uppercase tracking-wider">Unit Price</th>
                  <th className="px-6 py-4 text-right text-xs font-bold text-sky-500 uppercase tracking-wider">Cost</th>
                  <th className="px-6 py-4 text-center text-xs font-bold text-sky-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-center text-xs font-bold text-sky-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-sky-100">
                {products.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center">
                      <p className="text-sky-600 text-base">No products found.</p>
                      <p className="text-sky-500 text-sm mt-1">Add a new product to get started.</p>
                    </td>
                  </tr>
                ) : (
                  products.map((product) => (
                    <tr key={product.id} className="hover:bg-sky-50/50 transition-colors duration-150">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-sky-900">{product.code}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-sky-900">{product.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-sky-900">{product.category}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-sky-900 text-right">{formatCurrency(product.unit_price)}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-sky-900 text-right">{formatCurrency(product.cost)}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-center">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          product.status === 'active' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {product.status.charAt(0).toUpperCase() + product.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-center text-sm">
                        <button
                          onClick={() => {
                            // TODO: Implement edit functionality
                            console.log('Edit product:', product.id);
                          }}
                          className="text-sky-600 hover:text-sky-800 transition-colors duration-200"
                        >
                          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
} 