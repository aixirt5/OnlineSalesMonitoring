export { metadata } from '../metadata';

export default function ProductMasterfileLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
} 