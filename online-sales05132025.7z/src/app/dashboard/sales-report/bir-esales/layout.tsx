export { metadata } from '../../metadata';

export default function BirESalesLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
} 