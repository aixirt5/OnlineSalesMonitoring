'use client';

import { useEffect, useState } from 'react';
import React from 'react';
import { getSalesDb } from '@/lib/salesDb';
import { Order, OrderDetail, OrderComposition, OrderTaxDetail } from '@/types/sales';

interface BranchInfo {
  branch_name: string;
  branch_code: string;
}

interface TerminalInfo {
  terminal_no: string;
  branch_code: string;
}

export default function SalesReport() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [transactions, setTransactions] = useState<((Order & { id: number; details?: (OrderDetail & { id: number; compositions?: (OrderComposition & { id: number })[] })[]; tax_detail?: OrderTaxDetail })[])>([]);
  const [branchList, setBranchList] = useState<BranchInfo[]>([]);
  const [terminalList, setTerminalList] = useState<TerminalInfo[]>([]);
  const [selectedBranch, setSelectedBranch] = useState<string>('all');
  const [selectedTerminal, setSelectedTerminal] = useState<string>('all');
  const [dateRange, setDateRange] = useState(() => {
    const today = new Date().toISOString().split('T')[0];
    return {
      start: today,
      end: today
    };
  });
  const [expandedTransaction, setExpandedTransaction] = useState<number | null>(null);
  const [summaryStats, setSummaryStats] = useState({
    totalSales: 0,
    totalTransactions: 0,
    averageTicket: 0,
  });
  const [currentPage, setCurrentPage] = useState(1);
  const transactionsPerPage = 10;
  const totalPages = Math.ceil(transactions.length / transactionsPerPage);
  const paginatedTransactions = transactions.slice(
    (currentPage - 1) * transactionsPerPage,
    currentPage * transactionsPerPage
  );

  // Fetch unique branches and terminals from orders
  useEffect(() => {
    const fetchBranchesAndTerminals = async () => {
      try {
        const salesDb = getSalesDb();
        
        // Fetch unique branches from orders
        const { data: branchData, error: branchError } = await salesDb
          .from('orders')
          .select('branch_name, branch_code')
          .not('branch_name', 'is', null)
          .not('branch_code', 'is', null);
        
        if (branchError) throw branchError;

        // Remove duplicates and sort by branch name
        const uniqueBranches = Array.from(
          new Map(
            (branchData || []).map(item => 
              [`${item.branch_code}-${item.branch_name}`, item]
            )
          ).values()
        ).sort((a, b) => a.branch_name.localeCompare(b.branch_name));

        setBranchList(uniqueBranches);

        // Fetch unique terminals from orders
        const { data: terminalData, error: terminalError } = await salesDb
          .from('orders')
          .select('terminal_no, branch_code')
          .not('terminal_no', 'is', null)
          .not('branch_code', 'is', null);
        
        if (terminalError) throw terminalError;

        // Remove duplicates and sort by terminal number
        const uniqueTerminals = Array.from(
          new Map(
            (terminalData || []).map(item => 
              [`${item.branch_code}-${item.terminal_no}`, item]
            )
          ).values()
        ).sort((a, b) => a.terminal_no.localeCompare(b.terminal_no));

        setTerminalList(uniqueTerminals);
      } catch (err) {
        console.error('Error fetching branches and terminals:', err);
        setError('Failed to load branch and terminal data');
      }
    };

    fetchBranchesAndTerminals();
  }, []);

  // Filter terminals based on selected branch
  const filteredTerminals = terminalList.filter(terminal => 
    selectedBranch === 'all' || terminal.branch_code === selectedBranch
  );

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        setLoading(true);
        const salesDb = getSalesDb();

        const startDate = new Date(dateRange.start);
        startDate.setHours(0, 0, 0, 0);

        const endDate = new Date(dateRange.end);
        endDate.setHours(23, 59, 59, 999);

        let query = salesDb
          .from('orders')
          .select('*')
          .gte('log_date', startDate.toISOString())
          .lte('log_date', endDate.toISOString());

        // Add branch filter if selected
        if (selectedBranch !== 'all') {
          query = query.eq('branch_code', selectedBranch);
        }

        // Add terminal filter if selected
        if (selectedTerminal !== 'all') {
          query = query.eq('terminal_no', selectedTerminal);
        }

        const { data: orders, error: ordersError } = await query.select('*').order('log_date', { ascending: false });

        if (ordersError) throw ordersError;

        const ordersWithDetails = await Promise.all(
          (orders || []).map(async (order) => {
            const { data: details } = await salesDb
              .from('order_details')
              .select('*')
              .eq('order_id', order.order_id)
              .eq('branch_code', order.branch_code)
              .eq('terminal_no', order.terminal_no);

            // Filter out voided and refunded details
            const filteredDetails = (details || []).filter(detail => !detail.voided && !detail.refunded);

            // Fetch compositions for each order detail
            const detailsWithCompositions = await Promise.all(
              filteredDetails.map(async (detail) => {
                const { data: compositions } = await salesDb
                  .from('order_compositions')
                  .select('*')
                  .eq('order_detail_id', detail.order_detail_id);
                return { ...detail, compositions };
              })
            );

            // Fetch VAT/tax details for the order
            const { data: taxDetailsArr } = await salesDb
              .from('order_tax_details')
              .select('*')
              .eq('order_id', order.order_id)
              .eq('branch_code', order.branch_code)
              .eq('terminal_no', order.terminal_no);

            let tax_detail = undefined;
            if (taxDetailsArr && taxDetailsArr.length > 0) {
              // Initialize with zeros
              const summedTax = {
                ...taxDetailsArr[0], // Keep other fields from first record
                vatable_sales: 0,
                vat_amount: 0,
                vat_exempt: 0,
                zero_rated: 0,
                sc_vat_deduction: 0
              };
              
              // Sum all values
              taxDetailsArr.forEach(tax => {
                summedTax.vatable_sales += Number(tax.vatable_sales || 0);
                summedTax.vat_amount += Number(tax.vat_amount || 0);
                summedTax.vat_exempt += Number(tax.vat_exempt || 0);
                summedTax.zero_rated += Number(tax.zero_rated || 0);
                summedTax.sc_vat_deduction += Number(tax.sc_vat_deduction || 0);
              });
              
              tax_detail = summedTax;
            }

            return { ...order, details: detailsWithCompositions, tax_detail };
          })
        );

        setTransactions(ordersWithDetails);

        // Calculate total sales and average ticket using total_amount + service_charge
        const total = ordersWithDetails.reduce((sum, order) => {
          const orderTotal = order.details?.reduce((detailSum: number, detail: OrderDetail) => {
            if (!detail.voided && !detail.refunded) {
              return detailSum + detail.total_amount + detail.service_charge;
            }
            return detailSum;
          }, 0) || 0;
          
          return sum + orderTotal;
        }, 0);

        setSummaryStats({
          totalSales: total,
          totalTransactions: ordersWithDetails.length,
          averageTicket: ordersWithDetails.length ? total / ordersWithDetails.length : 0,
        });

      } catch (err) {
        console.error(err);
        setError('Failed to fetch transaction data');
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, [dateRange, selectedBranch, selectedTerminal]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'PHP',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  const toggleTransaction = (orderId: number) => {
    setExpandedTransaction(expandedTransaction === orderId ? null : orderId);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-200 via-sky-100 to-sky-300 p-2 sm:p-4 md:p-6 max-w-[1600px] mx-auto w-full overflow-x-hidden box-border">
      {/* Header Section */}
      <div className="mb-6 sm:mb-8">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-sky-700 tracking-tight drop-shadow-sm">Sales Report</h1>
        <p className="mt-1 sm:mt-2 text-sm sm:text-base text-sky-600">Detailed transaction report with comprehensive analytics</p>
      </div>

      {/* Filters and Summary Section */}
      <div className="mb-6 sm:mb-8 bg-white/90 rounded-2xl shadow-lg border border-sky-100">
        <div className="p-4 sm:p-8 space-y-6 sm:space-y-8">
          {/* Filters Section */}
          <div className="grid grid-cols-1 gap-4 sm:gap-8 md:grid-cols-2 lg:grid-cols-4">
            {/* Date Range Selector */}
            <div className="lg:col-span-2">
              <h3 className="text-xs sm:text-sm font-bold text-sky-600 mb-2 sm:mb-3">Select Date Range</h3>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:space-x-4">
                <div className="flex-1 relative">
                  <input
                    type="date"
                    value={dateRange.start}
                    onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
                    className="w-full border border-sky-300 bg-white/70 rounded-lg px-3 sm:px-4 py-2 text-xs sm:text-sm focus:ring-2 focus:ring-sky-400 focus:border-sky-400 shadow-sm transition-all duration-200"
                  />
                  <div className="absolute inset-y-0 right-2 sm:right-3 flex items-center pointer-events-none">
                    <svg className="h-4 w-4 sm:h-5 sm:w-5 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                </div>
                <span className="text-sky-500 font-medium text-xs sm:text-sm text-center">to</span>
                <div className="flex-1 relative">
                  <input
                    type="date"
                    value={dateRange.end}
                    onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
                    className="w-full border border-sky-300 bg-white/70 rounded-lg px-3 sm:px-4 py-2 text-xs sm:text-sm focus:ring-2 focus:ring-sky-400 focus:border-sky-400 shadow-sm transition-all duration-200"
                  />
                  <div className="absolute inset-y-0 right-2 sm:right-3 flex items-center pointer-events-none">
                    <svg className="h-4 w-4 sm:h-5 sm:w-5 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>

            {/* Branch Selector */}
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-sky-600 mb-2 sm:mb-3">Select Branch</h3>
              <div className="relative">
                <select
                  value={selectedBranch}
                  onChange={(e) => {
                    setSelectedBranch(e.target.value);
                    setSelectedTerminal('all'); // Reset terminal when branch changes
                  }}
                  className="w-full border border-sky-300 bg-white/70 rounded-lg px-3 sm:px-4 py-2 text-xs sm:text-sm focus:ring-2 focus:ring-sky-400 focus:border-sky-400 shadow-sm transition-all duration-200 appearance-none"
                >
                  <option value="all">All Branches</option>
                  {branchList.map((branch) => (
                    <option key={branch.branch_code} value={branch.branch_code}>
                      {branch.branch_name}
                    </option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-2 sm:right-3 flex items-center pointer-events-none">
                  <svg className="h-4 w-4 sm:h-5 sm:w-5 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Terminal Selector */}
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-sky-600 mb-2 sm:mb-3">Select Terminal</h3>
              <div className="relative">
                <select
                  value={selectedTerminal}
                  onChange={(e) => setSelectedTerminal(e.target.value)}
                  className="w-full border border-sky-300 bg-white/70 rounded-lg px-3 sm:px-4 py-2 text-xs sm:text-sm focus:ring-2 focus:ring-sky-400 focus:border-sky-400 shadow-sm transition-all duration-200 appearance-none"
                >
                  <option value="all">All Terminals</option>
                  {filteredTerminals.map((terminal) => (
                    <option key={`${terminal.branch_code}-${terminal.terminal_no}`} value={terminal.terminal_no}>
                      {terminal.terminal_no}
                    </option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-2 sm:right-3 flex items-center pointer-events-none">
                  <svg className="h-4 w-4 sm:h-5 sm:w-5 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>
          </div>

          {/* Summary Stats */}
          <div className="grid grid-cols-1 gap-4 sm:gap-8 md:grid-cols-3">
            <div className="bg-gradient-to-br from-sky-50 to-white p-4 sm:p-8 rounded-2xl border border-sky-100 shadow-md">
              <div className="flex items-center space-x-3 sm:space-x-4">
                <div className="p-2 sm:p-3 bg-sky-100 rounded-lg">
                  <svg className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <div className="text-xs sm:text-sm font-medium text-sky-500">Total Sales</div>
                  <div className="text-lg sm:text-2xl font-bold text-sky-700 mt-1">{formatCurrency(summaryStats.totalSales)}</div>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-cyan-50 to-white p-4 sm:p-8 rounded-2xl border border-cyan-100 shadow-md">
              <div className="flex items-center space-x-3 sm:space-x-4">
                <div className="p-2 sm:p-3 bg-cyan-100 rounded-lg">
                  <svg className="w-5 h-5 sm:w-6 sm:h-6 text-cyan-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <div>
                  <div className="text-xs sm:text-sm font-medium text-cyan-500">Transactions</div>
                  <div className="text-lg sm:text-2xl font-bold text-cyan-700 mt-1">{summaryStats.totalTransactions}</div>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-indigo-50 to-white p-4 sm:p-8 rounded-2xl border border-indigo-100 shadow-md">
              <div className="flex items-center space-x-3 sm:space-x-4">
                <div className="p-2 sm:p-3 bg-indigo-100 rounded-lg">
                  <svg className="w-5 h-5 sm:w-6 sm:h-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                </div>
                <div>
                  <div className="text-xs sm:text-sm font-medium text-indigo-500">Average Ticket</div>
                  <div className="text-lg sm:text-2xl font-bold text-indigo-700 mt-1">{formatCurrency(summaryStats.averageTicket)}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Transactions List */}
      {loading ? (
        <div className="flex flex-col items-center justify-center h-64 space-y-4">
          <div className="animate-spin rounded-full h-10 w-10 sm:h-12 sm:w-12 border-b-2 border-sky-500"></div>
          <p className="text-xs sm:text-sm text-sky-500">Loading transactions...</p>
        </div>
      ) : error ? (
        <div className="flex flex-col items-center justify-center h-64 space-y-4">
          <div className="p-3 sm:p-4 rounded-full bg-red-100">
            <svg className="w-7 h-7 sm:w-8 sm:h-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div className="text-red-600 font-semibold text-xs sm:text-base">{error}</div>
          <p className="text-xs sm:text-sm text-sky-500">Please try again later</p>
        </div>
      ) : transactions.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-64 space-y-4">
          <div className="p-3 sm:p-4 rounded-full bg-sky-100">
            <svg className="w-7 h-7 sm:w-8 sm:h-8 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
            </svg>
          </div>
          <p className="text-xs sm:text-sm text-sky-500">No transactions found for the selected date range</p>
        </div>
      ) : (
        <>
          <div className="space-y-4 sm:space-y-6">
            {paginatedTransactions.map((transaction, tIndex) => (
              <div
                key={transaction.id ?? `${transaction.order_id}-${tIndex}`}
                className="bg-white/90 rounded-2xl shadow-lg border border-sky-100 overflow-hidden transition-all duration-200 hover:shadow-xl hover:border-sky-200"
              >
                {/* Transaction Header */}
                <button
                  onClick={() => toggleTransaction(transaction.id)}
                  className="w-full px-4 sm:px-8 py-4 sm:py-5 flex flex-col sm:flex-row items-start sm:items-center justify-between bg-white/80 hover:bg-sky-50 transition-colors duration-200 gap-2 sm:gap-0"
                >
                  <div className="flex items-center space-x-3 sm:space-x-4 w-full sm:w-auto">
                    <div className="flex-shrink-0">
                      <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-lg bg-gradient-to-br from-sky-100 to-sky-50 flex items-center justify-center">
                        <span className="text-sky-700 font-semibold text-sm sm:text-base">#{transaction.trn}</span>
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-2">
                        <p className="text-sm sm:text-base font-semibold text-sky-900 truncate">
                          TRN: {transaction.trn}
                        </p>
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-sky-100 text-sky-800 mt-1 sm:mt-0">
                          {transaction.terminal_no}
                        </span>
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-sky-50 text-sky-800 mt-1 sm:mt-0">
                          {transaction.datetime ? formatDate(transaction.datetime) : formatDate(transaction.log_date)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-row sm:flex-col items-end sm:items-end space-x-2 sm:space-x-0 sm:space-y-1 w-full sm:w-auto justify-between sm:justify-end">
                    <div className="text-right">
                      <p className="text-base sm:text-lg font-semibold text-sky-900">
                        {formatCurrency(
                          transaction.details?.reduce((sum, detail) => {
                            if (!detail.voided && !detail.refunded) {
                              return sum + detail.total_amount + detail.service_charge;
                            }
                            return sum;
                          }, 0) || 0
                        )}
                      </p>
                      <div className="flex items-center mt-1 space-x-1 text-xs sm:text-sm text-sky-500">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                        <span>{transaction.cashier_name}</span>
                      </div>
                    </div>
                    <div className={`transform transition-transform duration-200 ${
                      expandedTransaction === transaction.id ? 'rotate-180' : ''
                    }`}>
                      <svg className="w-5 h-5 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </div>
                  </div>
                </button>

                {/* Transaction Details */}
                {expandedTransaction === transaction.id && (
                  <div className="border-t border-sky-100 px-2 sm:px-8 py-4 sm:py-5 animate-fadeIn bg-sky-50/50 overflow-x-auto">
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-sky-100 text-xs sm:text-sm">
                        <thead>
                          <tr>
                            <th scope="col" className="px-2 sm:px-3 py-2 sm:py-3 text-left text-xs font-bold text-sky-500 uppercase tracking-widest bg-sky-50 rounded-l-lg">Item</th>
                            <th scope="col" className="px-2 sm:px-3 py-2 sm:py-3 text-right text-xs font-bold text-sky-500 uppercase tracking-widest bg-sky-50">Qty</th>
                            <th scope="col" className="px-2 sm:px-3 py-2 sm:py-3 text-right text-xs font-bold text-sky-500 uppercase tracking-widest bg-sky-50">Unit Price</th>
                            <th scope="col" className="px-2 sm:px-3 py-2 sm:py-3 text-right text-xs font-bold text-sky-500 uppercase tracking-widest bg-sky-50 rounded-r-lg">Total</th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-sky-50">
                          {transaction.details?.map((detail, dIndex) => (
                            <React.Fragment key={detail.id ?? `${detail.order_detail_id}-${dIndex}`}>
                              <tr className={`${detail.voided ? 'bg-red-50' : ''} transition-colors duration-150 hover:bg-sky-50`}>
                                <td className="px-2 sm:px-3 py-2 sm:py-3 whitespace-nowrap text-sm text-gray-900">
                                  <div className="flex items-center">
                                    <span className={`font-medium ${detail.voided ? 'text-red-700' : ''}`}>{detail.menu_name}</span>
                                    {detail.voided && (
                                      <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-red-100 text-red-800">
                                        Voided
                                      </span>
                                    )}
                                  </div>
                                </td>
                                <td className="px-2 sm:px-3 py-2 sm:py-3 whitespace-nowrap text-sm text-gray-900 text-right font-medium">{detail.item_qty}</td>
                                <td className="px-2 sm:px-3 py-2 sm:py-3 whitespace-nowrap text-sm text-gray-900 text-right">{formatCurrency(detail.unit_price)}</td>
                                <td className="px-2 sm:px-3 py-2 sm:py-3 whitespace-nowrap text-sm text-gray-900 text-right font-medium">{formatCurrency(detail.total_amount)}</td>
                              </tr>
                              {/* Display compositions if they exist */}
                              {(detail.compositions?.filter(composition =>
                                (detail.compositions && detail.compositions.length > 1) || composition.product_name !== detail.menu_name
                              ) || []).map((composition, cIndex) => (
                                <tr 
                                  key={composition.id ?? `${composition.compo_id}-${cIndex}`}
                                  className={`${detail.voided ? 'bg-red-50' : 'bg-sky-50'} text-sm`}
                                >
                                  <td className="px-2 sm:px-3 py-2 pl-8 whitespace-nowrap text-gray-600">
                                    <div className="flex items-center">
                                      <span className="text-xs">⤷ {composition.product_name}</span>
                                      {composition.is_addon && (
                                        <span className="ml-2 inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                                          Add-on
                                        </span>
                                      )}
                                    </div>
                                  </td>
                                  <td className="px-2 sm:px-3 py-2 whitespace-nowrap text-right">{composition.quantity}</td>
                                  <td className="px-2 sm:px-3 py-2 whitespace-nowrap text-right">{formatCurrency(composition.amount)}</td>
                                  <td className="px-2 sm:px-3 py-2 whitespace-nowrap text-right">{formatCurrency(composition.amount * composition.quantity)}</td>
                                </tr>
                              ))}
                            </React.Fragment>
                          ))}
                        </tbody>
                        <tfoot>
                          <tr className="bg-sky-50">
                            <td colSpan={2} className="px-2 sm:px-3 py-2 sm:py-3 text-sm text-sky-500 font-medium">Subtotal</td>
                            <td colSpan={2} className="px-2 sm:px-3 py-2 sm:py-3 text-sm text-sky-900 text-right font-semibold">
                              {formatCurrency(
                                transaction.details?.reduce((sum, detail) => {
                                  if (!detail.voided && !detail.refunded) {
                                    return sum + detail.unit_price + (detail.addon_amount || 0);
                                  }
                                  return sum;
                                }, 0) || 0
                              )}
                            </td>
                          </tr>
                          {/* Show voided items total if any exist */}
                          {transaction.details?.some(detail => detail.voided || detail.refunded) && (
                            <tr className="bg-red-50">
                              <td colSpan={2} className="px-2 sm:px-3 py-2 sm:py-3 text-sm text-red-700 font-medium">Voided/Refunded Items</td>
                              <td colSpan={2} className="px-2 sm:px-3 py-2 sm:py-3 text-sm text-red-700 text-right font-semibold">
                                -{formatCurrency(
                                  transaction.details.reduce((sum, detail) => {
                                    if (detail.voided || detail.refunded) {
                                      return sum + detail.unit_price + (detail.addon_amount || 0);
                                    }
                                    return sum;
                                  }, 0)
                                )}
                              </td>
                            </tr>
                          )}
                          {/* Calculate service charge only for non-voided/non-refunded items */}
                          {transaction.service_charge > 0 && (
                            <>
                              <tr className="bg-sky-50">
                                <td colSpan={2} className="px-2 sm:px-3 py-2 sm:py-3 text-sm text-sky-500 font-medium">Service Charge</td>
                                <td colSpan={2} className="px-2 sm:px-3 py-2 sm:py-3 text-sm text-sky-900 text-right font-semibold">
                                  {formatCurrency(
                                    transaction.details?.reduce((sum, detail) => {
                                      if (!detail.voided && !detail.refunded) {
                                        return sum + detail.service_charge;
                                      }
                                      return sum;
                                    }, 0) || 0
                                  )}
                                </td>
                              </tr>
                              {/* Show voided service charge if there are voided items */}
                              {transaction.details?.some(detail => detail.voided || detail.refunded) && (
                                <tr className="bg-red-50">
                                  <td colSpan={2} className="px-2 sm:px-3 py-2 sm:py-3 text-sm text-red-700 font-medium">Voided/Refunded Service Charge</td>
                                  <td colSpan={2} className="px-2 sm:px-3 py-2 sm:py-3 text-sm text-red-700 text-right font-semibold">
                                    -{formatCurrency(
                                      transaction.details.reduce((sum, detail) => {
                                        if (detail.voided || detail.refunded) {
                                          return sum + detail.service_charge;
                                        }
                                        return sum;
                                      }, 0)
                                    )}
                                  </td>
                                </tr>
                              )}
                            </>
                          )}
                          {((transaction.amount_discount > 0) || (transaction.tax_detail && transaction.tax_detail.sc_vat_deduction > 0)) && (
                            <tr className="bg-sky-50">
                              <td colSpan={2} className="px-2 sm:px-3 py-2 sm:py-3 text-sm text-sky-500 font-medium">Discount</td>
                              <td colSpan={2} className="px-2 sm:px-3 py-2 sm:py-3 text-sm text-sky-900 text-right font-semibold">
                                -{formatCurrency((transaction.amount_discount || 0) + (transaction.tax_detail?.sc_vat_deduction || 0))}
                              </td>
                            </tr>
                          )}
                          <tr className="bg-sky-50 border-t-2 border-sky-200">
                            <td colSpan={2} className="px-2 sm:px-3 py-2 sm:py-3 text-sm font-semibold text-sky-900">Total</td>
                            <td colSpan={2} className="px-2 sm:px-3 py-2 sm:py-3 text-sm text-sky-900 text-right font-bold">
                              {formatCurrency(
                                (transaction.details?.reduce((sum, detail) => {
                                  if (!detail.voided && !detail.refunded) {
                                    return sum + detail.total_amount + detail.service_charge;
                                  }
                                  return sum;
                                }, 0) || 0)
                              )}
                            </td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                )}
                {/* VAT/Tax Details Section */}
                {transaction.tax_detail && (
                  <div className="mt-6 bg-sky-50 rounded-lg p-4 border border-sky-100">
                    <h4 className="text-sm font-semibold text-sky-700 mb-2">VAT Details</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div><span className="text-sky-500">Vatable Sales:</span> <span className="font-medium text-sky-900">{formatCurrency(transaction.tax_detail.vatable_sales)}</span></div>
                      <div><span className="text-sky-500">VAT Amount:</span> <span className="font-medium text-sky-900">{formatCurrency(transaction.tax_detail.vat_amount)}</span></div>
                      <div><span className="text-sky-500">VAT Exempt:</span> <span className="font-medium text-sky-900">{formatCurrency(transaction.tax_detail.vat_exempt)}</span></div>
                      <div><span className="text-sky-500">Zero Rated:</span> <span className="font-medium text-sky-900">{formatCurrency(transaction.tax_detail.zero_rated)}</span></div>
                      <div><span className="text-sky-500">SC VAT Deduction:</span> <span className="font-medium text-sky-900">{formatCurrency(transaction.tax_detail.sc_vat_deduction)}</span></div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
          {/* Pagination Controls */}
          <div className="flex justify-center items-center mt-8 space-x-4">
            <button
              className="px-4 py-2 rounded bg-sky-200 text-sky-700 font-medium disabled:opacity-50"
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
            >
              Previous
            </button>
            <span className="text-sky-700 font-medium">
              Page {currentPage} of {totalPages}
            </span>
            <button
              className="px-4 py-2 rounded bg-sky-200 text-sky-700 font-medium disabled:opacity-50"
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
            >
              Next
            </button>
          </div>
        </>
      )}
    </div>
  );
} 